#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        return 1;
    }
    else if (pid == 0) {
        /* Child process */
        printf("Child: This is the child process. PID: %d, PPID: %d\n", getpid(), getppid());
        /* child can do more work here */
    }
    else {
        /* Parent process */
        printf("Parent: This is the parent process. PID: %d, child PID: %d\n", getpid(), pid);
        /* Wait for the child to finish to avoid a zombie process */
        wait(NULL);
        printf("Parent: Child has terminated. Parent exiting.\n");
    }

    return 0;
}
