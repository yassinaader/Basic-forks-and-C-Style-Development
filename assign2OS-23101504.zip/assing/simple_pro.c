#include <stdio.h>

int main(void) {
    printf("This is a simple program.\n");
    return 0;
}
