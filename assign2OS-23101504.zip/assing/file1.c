#include <stdio.h>

void hello(void) {
    printf("Hello from file1!\n");
}
