#include <stdio.h>

void hello(void); /* forward declaration */

int main(void) {
    hello();
    return 0;
}
